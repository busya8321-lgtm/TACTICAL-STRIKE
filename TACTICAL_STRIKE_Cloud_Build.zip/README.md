# TACTICAL STRIKE — Android starter

This is a first Android prototype scaffold for a landscape, full-screen, 5v5-inspired arena shooter.

## Open and build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location.

## Prototype status
This starter contains the Android app shell, touch HUD, stylized arena screen, and placeholder team units. It is **not yet a finished realistic 3D shooter**: bot navigation, networking, detailed 3D assets, real match logic, sound, and weapon animations still need development. The included OpenGL renderer is a minimal foundation, while the current visible arena HUD is a 2D prototype.

The game uses fictional energy-pulse gameplay rather than reproducing real weapon operation.
