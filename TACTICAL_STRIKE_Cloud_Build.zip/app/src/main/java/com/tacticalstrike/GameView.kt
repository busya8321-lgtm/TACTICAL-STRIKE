package com.tacticalstrike

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.View
import android.graphics.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import android.opengl.GLES20
import android.opengl.Matrix
import kotlin.math.*

class GameView(ctx: Context) : View(ctx) {
    private val paint = Paint(3)
    private val gl = ArenaSurface(ctx)
    private var downX=0f; private var downY=0f
    private var moveX=0f; private var moveY=0f
    private var lookX=0f; private var fire=false
    private var score=0; private var health=100; private var ammo=24
    private var tick=0
    private val handler = android.os.Handler()
    private val loop = object: Runnable {
        override fun run() {
            if (fire && ammo>0) { ammo--; score += 1 }
            if (ammo==0) ammo=24
            tick++; invalidate(); handler.postDelayed(this, 1000)
        }
    }
    init { setLayerType(View.LAYER_TYPE_SOFTWARE,null); handler.post(loop) }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(13,20,28))
        val w=width.toFloat(); val h=height.toFloat()
        paint.color=Color.rgb(27,42,48); c.drawRect(0f,0f,w,h,paint)
        paint.color=Color.rgb(55,75,73)
        c.drawRect(w*.04f,h*.12f,w*.96f,h*.88f,paint)
        paint.color=Color.rgb(83,91,84)
        for(i in 0..5){val x=w*(.12f+i*.15f);c.drawRoundRect(x,h*.32f,x+45,h*.42f,5f,5f,paint)}
        paint.color=Color.rgb(37,49,57)
        c.drawRect(w*.43f,h*.2f,w*.57f,h*.8f,paint)
        // Stylized teammates and opponents in a tactical arena.
        for(i in 0..4){
            drawUnit(c,w*(.18f+i*.12f),h*(.28f+(i%2)*.38f),Color.rgb(55,190,175),"ALLY")
            drawUnit(c,w*(.68f+(i%3)*.07f),h*(.25f+(i%2)*.4f),Color.rgb(224,105,79),"BOT")
        }
        paint.color=Color.WHITE;paint.textSize=22f;paint.typeface=Typeface.DEFAULT_BOLD
        c.drawText("TACTICAL STRIKE",24f,34f,paint)
        paint.textSize=15f;paint.color=Color.LTGRAY
        c.drawText("5v5  •  ROUND 01  •  TRAINING ARENA",24f,58f,paint)
        paint.color=Color.rgb(24,31,39);c.drawRoundRect(w-220f,15f,w-18f,72f,12f,12f,paint)
        paint.color=Color.WHITE;paint.textSize=16f
        c.drawText("HP $health     ENERGY $ammo",w-205f,49f,paint)
        // Crosshair
        paint.color=Color.WHITE;paint.strokeWidth=2f
        c.drawLine(w*.5f-12,h*.5f,w*.5f-4,h*.5f,paint);c.drawLine(w*.5f+4,h*.5f,w*.5f+12,h*.5f,paint)
        c.drawLine(w*.5f,h*.5f-12,w*.5f,h*.5f-4,paint);c.drawLine(w*.5f,h*.5f+4,w*.5f,h*.5f+12,paint)
        // Touch joystick
        paint.color=0x665FFFFFF; c.drawCircle(90f,h-90f,58f,paint)
        paint.color=0xCCFFFFFF;c.drawCircle(90f+moveX, h-90f+moveY,23f,paint)
        // Fire button
        paint.color=0xAAE56D53.toInt();c.drawCircle(w-90f,h-90f,54f,paint)
        paint.color=Color.WHITE;paint.textSize=15f;c.drawText("PULSE",w-115f,h-85f,paint)
        paint.color=Color.WHITE;paint.textSize=14f
        c.drawText("SCORE $score",w-135f,h-160f,paint)
        paint.color=Color.LTGRAY;c.drawText("Move: left pad   Aim: drag   Pulse: right button",w*.34f,h-22f,paint)
    }
    private fun drawUnit(c:Canvas,x:Float,y:Float,color:Int,label:String){
        paint.color=0x55000000;c.drawOval(x-13,y+18,x+13,y+25,paint)
        paint.color=color;c.drawRoundRect(x-10,y-18,x+10,y+16,6f,6f,paint)
        paint.color=Color.rgb(210,195,164);c.drawCircle(x,y-23,8f,paint)
        paint.color=Color.WHITE;paint.textSize=9f;c.drawText(label,x-13,y-32,paint)
    }
    override fun onTouchEvent(e:MotionEvent):Boolean{
        val x=e.x;val y=e.y;val w=width.toFloat();val h=height.toFloat()
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN,MotionEvent.ACTION_POINTER_DOWN->{downX=x;downY=y
                if(x>w-165&&y>h-165)fire=true
                else if(x<180&&y>h-180){moveX=(x-90).coerceIn(-35f,35f);moveY=(y-(h-90)).coerceIn(-35f,35f)}
                else lookX=x
            }
            MotionEvent.ACTION_MOVE->{if(downX<180&&downY>h-180){moveX=(x-90).coerceIn(-35f,35f);moveY=(y-(h-90)).coerceIn(-35f,35f)}}
            MotionEvent.ACTION_UP,MotionEvent.ACTION_POINTER_UP,CANCEL->{fire=false;moveX=0f;moveY=0f}
        }
        invalidate();return true
    }
    private companion object { const val CANCEL=MotionEvent.ACTION_CANCEL }
}

private class ArenaSurface(context: Context): GLSurfaceView(context) {
    init { setEGLContextClientVersion(2); setRenderer(ArenaRenderer()); renderMode=RENDERMODE_CONTINUOUSLY }
}
private class ArenaRenderer: GLSurfaceView.Renderer {
    override fun onSurfaceCreated(gl:GL10?, config:EGLConfig?){GLES20.glClearColor(.05f,.09f,.12f,1f);GLES20.glEnable(GLES20.GL_DEPTH_TEST)}
    override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int){GLES20.glViewport(0,0,w,h)}
    override fun onDrawFrame(gl:GL10?){GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)}
}
